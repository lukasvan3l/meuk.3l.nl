﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;

namespace DbToTumblr
{
  public class RegularTumblrPost : AbstractTumblrPost
  {

    public RegularTumblrPost(string Generator, string Tags, DateTime Created, string Title, string Body)
      : base(Type.regular, Generator, Tags, Created)
    {
      values.Add("title", Title);
      values.Add("body", Body);
    }

    public override string ToString()
    {
      return values["title"] + "\n" + values["body"];
    }

  }

}