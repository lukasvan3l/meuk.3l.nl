﻿using System;
using System.Collections.Generic;
using System.Text;
using Q42.Wheels.Sql;
using Q42.Wheels.Sql.Sqlite;
using System.Net;
using System.IO;

namespace DbToTumblr
{
  class Program
  {
    private const string ConnectionString = @"Data Source=c:\inetpub\wwwroot\DbToTumblr\Data\3L-original.db;Version=3;New=True;";
    private static SqlDriver drv = new SqliteDriver(ConnectionString);
    private const string TumblrUsername = "";
    private const string TumblrPassword = "";

    static void Main(string[] args)
    {
      //ImportG4g();
      //ImportNijntjeMustDie();
      //ImportGeblaat();
      //ImportLog();
      Console.ReadKey(true);
    }

    private static void ImportNijntjeMustDie()
    {
      throw new NotImplementedException();
    }

    private static void ImportG4g()
    {

      SqlQuery query = new SqlQuery(drv, "select * from g4g order by datum asc");

      foreach (Record result in query.GetRecordList())
      {
        RegularTumblrPost post = new RegularTumblrPost(
          "3l.nl",
          "3l.nl,giftsforgirls,g4g",
          (DateTime)result["datum"],
          result["titel"].ToString(),
          GetBody(result["intro"].ToString()));

        SendToTumblr(post);
      }
    }

    private static void ImportGeblaat()
    {
      SqlQuery query = new SqlQuery(drv, "select * from geblaat order by datum asc");

      foreach (Record result in query.GetRecordList())
      {
        QuoteTumblrPost post = new QuoteTumblrPost(
          "3l.nl",
          "3l.nl,geblaat",
          (DateTime)result["datum"],
          GetBody(result["bericht"].ToString()),
          result["naam"].ToString());

        SendToTumblr(post);
      }
    }

    static void ImportLog()
    {
      SqlQuery query = new SqlQuery(drv, "select * from log where tonen = 1 order by datum asc");

      foreach (Record result in query.GetRecordList())
      {
        RegularTumblrPost post = new RegularTumblrPost(
          "3l.nl", 
          "3l.nl", 
          (DateTime)result["datum"],
          result["titel"].ToString(), 
          GetBody(result["bericht"].ToString()));

        SendToTumblr(post);
      }

    }

    static void SendToTumblr(AbstractTumblrPost post)
    {
      Console.WriteLine("About to post: " + post.ToString());
      //return;
      post.values.Add("email", TumblrUsername);
      post.values.Add("password", TumblrPassword);

      WebClient webClient = new WebClient();
      byte[] responseBytes = webClient.UploadValues("http://www.tumblr.com/api/write", "POST", post.values);
      string resultAuthTicket = Encoding.UTF8.GetString(responseBytes);
    }

    static string GetBody(string bericht)
    {
      string body = bericht.Trim();
      body = body.Replace("\\r\\n", "<br />");
      body = body.Replace("\\r\\n", "");
      body = body.Replace("&#39", "'");
      body = body.Replace("\\\"", "\"");
      return body;
    }
  }
}
