﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;

namespace DbToTumblr
{
  public abstract class AbstractTumblrPost
  {

    public NameValueCollection values;

    public AbstractTumblrPost(Type type, string Generator, string Tags, DateTime Created)
    {
      values = new NameValueCollection();

      values.Add("format", Format.html.ToString());
      values.Add("state", State.published.ToString());
      values.Add("send-to-twitter", SendToTwitter.no.ToString());

      values.Add("type", type.ToString());
      values.Add("tags", Tags);
      values.Add("generator", Generator);
      values.Add("date", Created.ToString("yyyy-MM-dd HH:mm:ss"));
    }

    public override string ToString()
    {
      return values["date"] + "\n" + values["type"];
    }

  }

  public enum State { published, draft, submission }
  public enum Format { html, markdown }
  public enum SendToTwitter { no, auto }
  public enum Type { regular, photo, quote, link, conversation, video, audio }

}
