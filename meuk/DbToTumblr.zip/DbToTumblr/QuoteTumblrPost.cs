﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;

namespace DbToTumblr
{
  public class QuoteTumblrPost : AbstractTumblrPost
  {

    public QuoteTumblrPost(string Generator, string Tags, DateTime Created, string Quote, string Source)
      : base(Type.quote, Generator, Tags, Created)
    {
      values.Add("quote", Quote);
      values.Add("source", Source);
    }

    public override string ToString()
    {
      return values["source"] + "\n" + values["quote"];
    }

  }

}